# AWS Elastic Beanstalk Deployment Script

Write-Host "Building FastTag Backend for AWS..." -ForegroundColor Green

# Install EB CLI if not present
if (!(Get-Command eb -ErrorAction SilentlyContinue)) {
    Write-Host "Installing AWS Elastic Beanstalk CLI..." -ForegroundColor Yellow
    pip install awsebcli
}

# Build the project
Write-Host "Building TypeScript..." -ForegroundColor Cyan
npm run build

# Create deployment zip - exclude heavy directories
Write-Host "Creating deployment package..." -ForegroundColor Cyan
$excludeDirs = @("node_modules", ".git", ".vercel", ".elasticbeanstalk")
$excludeFiles = @("*.md", "test-*.js", "deploy.zip", ".env")

$files = Get-ChildItem -Path . | Where-Object {
    $item = $_
    $excludeMatch = $false
    foreach ($dir in $excludeDirs) {
        if ($item.Name -eq $dir -and $item.PSIsContainer) { $excludeMatch = $true }
    }
    foreach ($pattern in $excludeFiles) {
        if ($item.Name -like $pattern) { $excludeMatch = $true }
    }
    -not $excludeMatch
}

Remove-Item deploy.zip -ErrorAction SilentlyContinue
$files | Compress-Archive -DestinationPath deploy.zip

# Deploy using EB CLI
Write-Host "Deploying to AWS Elastic Beanstalk..." -ForegroundColor Cyan

# Check if environment exists
$envExists = eb list | Select-String "fasttag-backend-prod"

if ($envExists) {
    eb deploy fasttag-backend-prod
} else {
    Write-Host "Creating new Elastic Beanstalk environment (Single Instance)..." -ForegroundColor Yellow
    eb create fasttag-backend-prod --platform "Node.js 20" --region ap-south-1 --single
}

Write-Host "Deployment complete!" -ForegroundColor Green
Write-Host "Check your application at: http://fasttag-backend-prod.elasticbeanstalk.com" -ForegroundColor Cyan
